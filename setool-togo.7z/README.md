# Setool Master源代码版本
1. 版本:2.6.2
2. 本版本是项目的源代码，可直接在终端内输入:python3 setool.py进行运行
3. 发型于:2022.3.5
4. 作者:LinWInCloud

# 源代码
这个是真的Setool Master的python源代码项目，你可以选择修改引用
