echo [*]start seeker-master
cd seeker-master
python3 seeker.py -t manual 